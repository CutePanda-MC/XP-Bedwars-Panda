fill ~-3 ~ ~-3 ~3 ~ ~3 air replace minecraft:slime
kill @s