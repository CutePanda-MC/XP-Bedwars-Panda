#初始化时间值
scoreboard players set @s rescue_platform_time -1

#原填充方案
#execute at @p run structure load items:bw_rescue_platform ~-3 ~-7 ~-3

#填充
execute at @p if block ~-1 ~-7 ~-3 minecraft:air run setblock ~-1 ~-7 ~-3 minecraft:slime
execute at @p if block ~1 ~-7 ~-3 minecraft:air run setblock ~1 ~-7 ~-3 minecraft:slime
execute at @p if block ~-2 ~-7 ~-2 minecraft:air run setblock ~-2 ~-7 ~-2 minecraft:slime
execute at @p if block ~-1 ~-7 ~-2 minecraft:air run setblock ~-1 ~-7 ~-2 minecraft:slime
execute at @p if block ~ ~-7 ~-2 minecraft:air run setblock ~ ~-7 ~-2 minecraft:slime
execute at @p if block ~1 ~-7 ~-2 minecraft:air run setblock ~1 ~-7 ~-2 minecraft:slime
execute at @p if block ~2 ~-7 ~-2 minecraft:air run setblock ~2 ~-7 ~-2 minecraft:slime
execute at @p if block ~-3 ~-7 ~-1 minecraft:air run setblock ~-3 ~-7 ~-1 minecraft:slime
execute at @p if block ~-2 ~-7 ~-1 minecraft:air run setblock ~-2 ~-7 ~-1 minecraft:slime
execute at @p if block ~-1 ~-7 ~-1 minecraft:air run setblock ~-1 ~-7 ~-1 minecraft:slime
execute at @p if block ~ ~-7 ~-1 minecraft:air run setblock ~ ~-7 ~-1 minecraft:slime
execute at @p if block ~1 ~-7 ~-1 minecraft:air run setblock ~1 ~-7 ~-1 minecraft:slime
execute at @p if block ~2 ~-7 ~-1 minecraft:air run setblock ~2 ~-7 ~-1 minecraft:slime
execute at @p if block ~3 ~-7 ~-1 minecraft:air run setblock ~3 ~-7 ~-1 minecraft:slime
execute at @p if block ~-2 ~-7 ~ minecraft:air run setblock ~-2 ~-7 ~ minecraft:slime
execute at @p if block ~-1 ~-7 ~ minecraft:air run setblock ~-1 ~-7 ~ minecraft:slime
execute at @p if block ~ ~-7 ~ minecraft:air run setblock ~ ~-7 ~ minecraft:slime
execute at @p if block ~1 ~-7 ~ minecraft:air run setblock ~1 ~-7 ~ minecraft:slime
execute at @p if block ~2 ~-7 ~ minecraft:air run setblock ~2 ~-7 ~ minecraft:slime
execute at @p if block ~-3 ~-7 ~1 minecraft:air run setblock ~-3 ~-7 ~1 minecraft:slime
execute at @p if block ~-2 ~-7 ~1 minecraft:air run setblock ~-2 ~-7 ~1 minecraft:slime
execute at @p if block ~-1 ~-7 ~1 minecraft:air run setblock ~-1 ~-7 ~1 minecraft:slime
execute at @p if block ~ ~-7 ~1 minecraft:air run setblock ~ ~-7 ~1 minecraft:slime
execute at @p if block ~1 ~-7 ~1 minecraft:air run setblock ~1 ~-7 ~1 minecraft:slime
execute at @p if block ~2 ~-7 ~1 minecraft:air run setblock ~2 ~-7 ~1 minecraft:slime
execute at @p if block ~3 ~-7 ~1 minecraft:air run setblock ~3 ~-7 ~1 minecraft:slime
execute at @p if block ~-2 ~-7 ~2 minecraft:air run setblock ~-2 ~-7 ~2 minecraft:slime
execute at @p if block ~-1 ~-7 ~2 minecraft:air run setblock ~-1 ~-7 ~2 minecraft:slime
execute at @p if block ~ ~-7 ~2 minecraft:air run setblock ~ ~-7 ~2 minecraft:slime
execute at @p if block ~1 ~-7 ~2 minecraft:air run setblock ~1 ~-7 ~2 minecraft:slime
execute at @p if block ~2 ~-7 ~2 minecraft:air run setblock ~2 ~-7 ~2 minecraft:slime
execute at @p if block ~-1 ~-7 ~3 minecraft:air run setblock ~-1 ~-7 ~3 minecraft:slime
execute at @p if block ~1 ~-7 ~3 minecraft:air run setblock ~1 ~-7 ~3 minecraft:slime

#传送以清除
execute at @p run tp @s ~ ~-7 ~