# ===== 重置玩家的末影箱 =====
# 用于重置玩家的末影箱。

# 调用此方法时：
# · 执行者需设定为玩家
# · 执行位置任意
# 输出结果：
# · 清空执行者的末影箱。

replaceitem entity @s slot.enderchest 0 air
replaceitem entity @s slot.enderchest 1 air
replaceitem entity @s slot.enderchest 2 air
replaceitem entity @s slot.enderchest 3 air
replaceitem entity @s slot.enderchest 4 air
replaceitem entity @s slot.enderchest 5 air
replaceitem entity @s slot.enderchest 6 air
replaceitem entity @s slot.enderchest 7 air
replaceitem entity @s slot.enderchest 8 air
replaceitem entity @s slot.enderchest 9 air
replaceitem entity @s slot.enderchest 10 air
replaceitem entity @s slot.enderchest 11 air
replaceitem entity @s slot.enderchest 12 air
replaceitem entity @s slot.enderchest 13 air
replaceitem entity @s slot.enderchest 14 air
replaceitem entity @s slot.enderchest 15 air
replaceitem entity @s slot.enderchest 16 air
replaceitem entity @s slot.enderchest 17 air
replaceitem entity @s slot.enderchest 18 air
replaceitem entity @s slot.enderchest 19 air
replaceitem entity @s slot.enderchest 20 air
replaceitem entity @s slot.enderchest 21 air
replaceitem entity @s slot.enderchest 22 air
replaceitem entity @s slot.enderchest 23 air
replaceitem entity @s slot.enderchest 24 air
replaceitem entity @s slot.enderchest 25 air
replaceitem entity @s slot.enderchest 26 air
