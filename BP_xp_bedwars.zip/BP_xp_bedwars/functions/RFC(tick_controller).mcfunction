#救援平台消失计时
scoreboard players add @e[type=bedwars:rescue_platform,scores={rescue_platform_time=-1..138}] rescue_platform_time 1
execute as @e[type=bedwars:rescue_platform,scores={rescue_platform_time=139}] at @e[type=bedwars:rescue_platform,scores={rescue_platform_time=139}] run function gameplay/kill_rescue_platform
