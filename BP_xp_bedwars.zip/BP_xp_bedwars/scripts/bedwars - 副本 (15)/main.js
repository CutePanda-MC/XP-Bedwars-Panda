import { system, world } from "@minecraft/server";
import { regenerateMap, map } from "./maps.js";
import * as bedwarsEvents from "./events.js";
import * as bot from "./bot.js"
import { xp } from "./xp.js"
import {newCommand} from "./command.js"
import { overworld } from "./constants.js";
import { eachPlayer } from "./methods.js";
import { GameSystem } from "./system.js";

    //system.beforeEvents.startup.subscribe((init)=>{newCommand(init)})

    /** 起床战争功能 - 事件订阅会在地图创建后注册（见下方 regenerateMap 调用位置） */

    GameSystem.afterGameEvents.afterMapCreate.subscribe( ( event ) => {
        GameSystem.Interval( ()=> {
            return bedwarsEvents.effectFunction()
        },20)
        GameSystem.Interval( ()=> {
            return bedwarsEvents.waitingFunction()
        },1)
    } )
    /**GameSystem.afterGameEvents.afterGameInit.subscribe( ( event ) => {
        GameSystem.Interval( ()=> {
            return bedwarsEvents.waitingFunction()
        },1)
    })*/
    GameSystem.afterGameEvents.afterGameStart.subscribe( ( event ) => {
        GameSystem.Interval( ()=> {
            return bedwarsEvents.EPsimple();
        },1)
        GameSystem.Interval( ()=> {
            return bedwarsEvents.EVPsimple();
        },1)
        GameSystem.Interval( ()=> {
            return bedwarsEvents.ETsimple();
        },1)
        GameSystem.Interval( ()=> {
            return bedwarsEvents.spawnResourceFunction();
        },5)
        GameSystem.Interval( ()=> {
            return bedwarsEvents.scoreboardFunction();
        },20)
        GameSystem.Interval( ()=> {
            return bedwarsEvents.gameEventFunction();
        },20)
        GameSystem.Interval( ()=> {
            return bedwarsEvents.teamFunction();
        },20)
    })
    GameSystem.afterGameEvents.afterGameEnd.subscribe( ( event ) => {
        GameSystem.Interval( ()=> {
            return bedwarsEvents.gameOverEvent()
        },20)
    })
        /** 立即生成地图（afterMapCreate 监听器已注册） */
        regenerateMap();

        /** 注册世界相关的事件订阅（需要在地图存在时注册） */
        if ( map() !== undefined ) {
            world.beforeEvents.playerBreakBlock.subscribe( event => { bedwarsEvents.playerBreakBlockEvent( event ); } )
            world.afterEvents.itemCompleteUse.subscribe( event => { bedwarsEvents.playerUsePotionAndMagicMilkEvent( event );} )
            world.afterEvents.projectileHitEntity.subscribe( event => { bedwarsEvents.bedBugEvent( event ); bedwarsEvents.hurtByFireballsEvent( event ); bedwarsEvents.enderPearlEvent( event); bedwarsEvents.arrowHit(event) } )
            world.afterEvents.projectileHitBlock.subscribe( event => { bedwarsEvents.bedBugEvent( event ); bedwarsEvents.hurtByFireballsEvent( event ); bedwarsEvents.enderPearlEvent( event ) } )
            world.beforeEvents.itemUse.subscribe( event => { bedwarsEvents.dreamDefenderEvent( event ); } )
            world.afterEvents.itemUse.subscribe( event => { bedwarsEvents.playerUseWaterBucketEvent( event ); bedwarsEvents.playerUseBridgeEggEvent( event ); bedwarsEvents.playerUseFireballEvent( event )} )
            world.afterEvents.playerPlaceBlock.subscribe( event => { bedwarsEvents.playerUseTNTEvent( event ); bedwarsEvents.towerAndWall( event );bedwarsEvents.playerUseItemOnHeightLimitEvent( event ); } )
            world.beforeEvents.explosion.subscribe( event => { bedwarsEvents.explosionEvents( event ); } )
            world.afterEvents.entityHurt.subscribe( event => { bedwarsEvents.hurtByPlayerEvent( event );} )
            world.afterEvents.entityDie.subscribe( event => { bedwarsEvents.playerDieEvent( event ); } )
            world.afterEvents.playerSpawn.subscribe( event => { bedwarsEvents.playerRejoinEvent( event ); } )
            world.beforeEvents.playerLeave.subscribe( event => { bedwarsEvents.playerLeaveEvent( event ); } )
            world.beforeEvents.chatSend.subscribe( event => {bot.makeBot( event )})
            world.afterEvents.playerInteractWithEntity.subscribe( event => { bedwarsEvents.afterInteractWithTraderEvent( event ); } )
            world.beforeEvents.playerInteractWithEntity.subscribe( event => { bedwarsEvents.beforeInteractWithTraderEvent( event ); } )
            world.beforeEvents.playerInteractWithBlock.subscribe( event => { bedwarsEvents.avoidInteractWithBed( event ); } )
            world.afterEvents.playerInventoryItemChange.subscribe( event => { bedwarsEvents.fastShopFunction( event );})
            system.afterEvents.scriptEventReceive.subscribe( event => { bedwarsEvents.settingsEvent( event ) } )
        }