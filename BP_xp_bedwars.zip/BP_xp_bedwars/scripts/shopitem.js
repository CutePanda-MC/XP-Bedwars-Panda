/** 商店物品 */
import { world, Player } from "@minecraft/server";
import { overworld } from "./constants";
import { BedwarsPlayer, eachValidPlayer, entityHasItemAmount, giveItem, itemInfo, resourceTypeToResourceId, warnPlayer, eachPlayer, playerIsAlive } from "./methods";
import { map } from "./maps.js";

// === 核心类定义 ===
    class Shopitem {
        constructor(id, traderType, costXP, itemAmount, options = {}) {
            this.traderType = traderType;
            this.id = id;
            this.itemId = `bedwars:${this.id}`;
            if (options.itemId) this.itemId = options.itemId;
            this.costXP = costXP;
            if (options.costXPInSolo) this.costXPInSolo = options.costXPInSolo;
            this.itemAmount = itemAmount;
            if (options.description) this.description = options.description;
            if (options.tier) this.tier = options.tier;
            this.buyCount = options.buyCount ?? -1;
            this.isHighestTier = options.isHighestTier ?? true;
            this.loseTierUponDeath = options.loseTierUponDeath ?? false;
            this.itemType = options.itemType ?? "other";
            this.costResourceType = options.costResourceType ?? null;
            this.costResourceAmount = options.costResourceAmount ?? 0;
            this.costResourceAmountInSolo = options.costResourceAmountInSolo ?? 0;
            
            this.shopitemId = (this.itemType === "teamUpgrade" || this.itemType === "trap") ? 
                `bedwars:upgrade_${this.id}` : `bedwars:shopitem_${this.id}`;
        }

        getCostXP() {
            if (map()?.isSolo() && this.costXPInSolo > 0) return this.costXPInSolo;
            return this.costXP;
        }

        getCostResourceAmount() {
            if (map()?.isSolo() && this.costResourceAmountInSolo > 0) return this.costResourceAmountInSolo;
            return this.costResourceAmount;
        }

        setColoredId(color) {
            if (this.itemType === "coloredBlock") this.itemId = `bedwars:${color}_${this.id}`;
        }

        generateLore() {
            // 团队升级使用资源
            if (this.itemType === "teamUpgrade" || this.itemType === "trap") {
                let resourceColor, resourceName;
                switch (this.costResourceType) {
                    case "iron": resourceColor = "§f"; resourceName = "铁锭"; break;
                    case "gold": resourceColor = "§6"; resourceName = "金锭"; break;
                    case "diamond": resourceColor = "§b"; resourceName = "钻石"; break;
                    case "emerald": resourceColor = "§2"; resourceName = "绿宝石"; break;
                    default: resourceColor = ""; resourceName = ""; break;
                }
                return ["", `§r§7花费：${resourceColor}${this.getCostResourceAmount()} ${resourceName}`, "", `§r§7${this.description}`];
            }
            
            // 其他物品使用经验值
            const xpCost = this.getCostXP();
            const xpText = `§a${xpCost} 经验值`;
            
            if (this.tier !== 0) {
                let itemTierName = ""; 
                switch (this.tier) {
                    case 1: itemTierName = "§eI"; break;
                    case 2: itemTierName = "§eII"; break;
                    case 3: itemTierName = "§eIII"; break;
                    case 4: itemTierName = "§eIV"; break;
                }
                
                if (this.loseTierUponDeath) {
                    if (!this.isHighestTier) {
                        return ["", `§r§7花费：${xpText}`, `§r§7等级：${itemTierName}`, "", "§r§7此道具可升级。", "§r§7死亡将会导致损失一级！", "", "§r§7每次重生时，至少为最低等级。"];
                    } else {
                        return ["", `§r§7花费：${xpText}`, `§r§7等级：${itemTierName}`, "", "§r§7此道具为最高等级。", "§r§7死亡将会导致损失一级！", "", "§r§7每次重生时，至少为最低等级。"];
                    }
                } else {
                    return ["", `§r§7花费：${xpText}`, `§r§7等级：${itemTierName}`, "", `§r§7${this.description}`];
                }
            } else {
                return this.description ? 
                    ["", `§r§7花费：${xpText}`, "", `§r§7${this.description}`] : 
                    ["", `§r§7花费：${xpText}`];
            }
        }

        setTraderItem(slotLocation) {
            const item = itemInfo(this.shopitemId, { 
                amount: this.itemAmount, 
                lore: this.generateLore() 
            });
            
            const traders = overworld.getEntities({ type: "bedwars:trader" }).filter(trader => {
                const typeFamily = trader.getComponent("minecraft:type_family");
                return typeFamily && typeFamily.hasTypeFamily(`${this.traderType}_trader`);
            });
            
            traders.forEach(trader => {
                const inventory = trader.getComponent("minecraft:inventory")?.container;
                if (!inventory) return;
                
                const currentItem = inventory.getItem(slotLocation);
                
                if (!currentItem || currentItem.typeId !== this.shopitemId || currentItem.amount !== this.itemAmount) {
                    inventory.setItem(slotLocation, item);
                }
            });
        }

        playerPurchaseItems(player) {
            if (player.runCommand(`execute if entity @s[hasitem={item=${this.shopitemId}}]`)?.successCount !== 1) return;
            
            player.runCommand(`clear @s ${this.shopitemId}`);
            const playerInfo = player.bedwarsInfo;
            if (!playerInfo) {
                warnPlayer(player, { translate: "message.invalidPlayer.purchaseItems" });
                return;
            }
            
            const playerTeam = playerInfo.getTeam?.();
            if (!playerTeam) {
                warnPlayer(player, { translate: "message.invalidTeam" });
                return;
            }
            
            const purchaseTest = (callback, options = {}) => {
                const defaults = { 
                    itemGot: false, isTeamUpgrade: false, costAdder: 0, 
                    currentLevel: 0, name: "", trapQueueFull: false 
                };
                const opt = { ...defaults, ...options };
                
                let realCost = 0;
                let resourceId = "";
                let isResourceCost = false;
                let costLevels = 0;
                
                // 团队升级使用资源
                if (this.itemType === "teamUpgrade" || this.itemType === "trap") {
                    realCost = this.getCostResourceAmount() + opt.costAdder;
                    resourceId = resourceTypeToResourceId(this.costResourceType);
                    isResourceCost = true;
                } else {
                    realCost = this.getCostXP() + opt.costAdder;
                    costLevels = realCost;
                }
                
                // 条件检查
                if (opt.itemGot || (this.tier !== 0 && this.tier < opt.currentLevel + 1)) {
                    warnPlayer(player, { translate: "message.alreadyGotItem" });
                    return;
                }
                
                if (this.buyCount === 0) {
                    warnPlayer(player, { translate: "message.buyCountZero" });
                    return;
                }
                
                if (this.tier !== 0 && this.tier > opt.currentLevel + 1) {
                    switch (this.itemType) {
                        case "axe": 
                            warnPlayer(player, { translate: "message.needItem", with: { rawtext: [{ translate: `message.bedwars:shopitem_${opt.name}_axe` }] } });
                            break;
                        case "pickaxe": 
                            warnPlayer(player, { translate: "message.needItem", with: { rawtext: [{ translate: `message.bedwars:shopitem_${opt.name}_pickaxe` }] } });
                            break;
                        case "teamUpgrade": 
                            warnPlayer(player, { translate: "message.needItem", with: { rawtext: [{ translate: `message.bedwars:upgrade_${opt.name}_tier_${this.tier - 1}` }] } });
                            break;
                    }
                    return;
                }
                
                if (this.itemType === "trap" && opt.trapQueueFull) {
                    warnPlayer(player, { translate: "message.trapQueueFull" });
                    return;
                }
                
                if (isResourceCost) {
                    if (player.runCommand(`execute if entity @s[hasitem={item=${resourceId},quantity=${realCost}..}]`)?.successCount !== 1) {
                        warnPlayer(player, { 
                            translate: "message.resourceNotEnough", 
                            with: { rawtext: [{ translate: `item.${resourceId}` }, { text: `${realCost}` }] } 
                        });
                        return;
                    }
                } else {
                    if (player.level < costLevels) {
                        warnPlayer(player, { 
                            translate: "message.levelsNotEnough", 
                            with: { rawtext: [{ text: `${costLevels}` }] } 
                        });
                        return;
                    }
                }
                
                // 执行购买
                if (isResourceCost) {
                    player.runCommand(`clear @s ${resourceId} 0 ${realCost}`);
                } else {
                    player.addLevels(-costLevels);
                }
                
                if (!opt.isTeamUpgrade) {
                    player.playSound("note.pling", { pitch: 2, location: player.location });
                    player.sendMessage({ translate: "message.purchaseItemsSuccessfully", with: { rawtext: [{ translate: `message.${this.shopitemId}` }] } });
                } else {
                    eachValidPlayer(teamPlayer => {
                        if (teamPlayer.bedwarsInfo?.team === player.bedwarsInfo?.team) {
                            teamPlayer.sendMessage({ 
                                translate: "message.purchaseTeamUpgradeSuccessfully", 
                                with: { rawtext: [{ text: player.name }, { translate: `message.${this.shopitemId}` }] } 
                            });
                            teamPlayer.playSound("note.pling", { pitch: 2, location: teamPlayer.location });
                            this.buyCount--;
                        }
                    });
                }
                callback?.();
            };
            
            const playerTeamUpgrade = playerTeam.teamUpgrade;
            switch (this.itemType) {
                case "sword":
                    purchaseTest(() => {
                        player.runCommand("clear @s bedwars:wooden_sword");
                        if (!playerTeamUpgrade?.sharpenedSwords) {
                            giveItem(player, this.itemId, { amount: 1, itemLock: "inventory" });
                        } else {
                            giveItem(player, this.itemId, { 
                                enchantments: [{ id: "sharpness", level: 1 }], 
                                itemLock: "inventory" 
                            });
                        }
                    });
                    break;
                    
                case "armor":
                    const itemTier = this.id === "chain_armor" ? 2 : 
                                    this.id === "iron_armor" ? 3 : 
                                    this.id === "diamond_armor" ? 4 : 
                                    this.id === "netherite_armor" ? 5 : 1;
                    purchaseTest(() => {
                        playerInfo.equipment.armor = itemTier; 
                    }, { itemGot: playerInfo.equipment?.armor >= itemTier });
                    break;
                    
                case "axe":
                    purchaseTest(() => {
                        playerInfo.equipment.axe++;
                        player.runCommand("clear @s bedwars:wooden_axe");
                        player.runCommand("clear @s bedwars:stone_axe");
                        player.runCommand("clear @s bedwars:iron_axe");
                    }, { 
                        currentLevel: playerInfo.equipment?.axe ?? 0, 
                        name: this.tier === 2 ? "wooden" : 
                             (this.tier === 3 ? "stone" : 
                             (this.tier === 4 ? "iron" : "wooden")) 
                    });
                    break;
                    
                case "pickaxe":
                    purchaseTest(() => {
                        playerInfo.equipment.pickaxe++;
                        player.runCommand("clear @s bedwars:wooden_pickaxe");
                        player.runCommand("clear @s bedwars:iron_pickaxe");
                        player.runCommand("clear @s bedwars:golden_pickaxe");
                    }, { 
                        currentLevel: playerInfo.equipment?.pickaxe ?? 0, 
                        name: this.tier === 2 ? "wooden" : 
                             (this.tier === 3 ? "iron" : 
                             (this.tier === 4 ? "golden" : "wooden")) 
                    });
                    break;
                    
                case "coloredBlock":
                    purchaseTest(() => {
                        this.setColoredId(playerInfo.team);
                        giveItem(player, this.itemId, { amount: this.itemAmount, itemLock: "inventory" });
                    });
                    break;
                    
                case "knockbackStick":
                    purchaseTest(() => {
                        giveItem(player, "bedwars:knockback_stick", { 
                            enchantments: [{ id: "knockback", level: 1 }] 
                        });
                    });
                    break;
                    
                case "shears":
                    purchaseTest(() => {
                        playerInfo.equipment.shears = 1;
                    }, { itemGot: playerInfo.equipment?.shears > 0 });
                    break;
                    
                case "bow":
                    purchaseTest(() => {
                        let enchantments = [];
                        if (this.id === "bow_power") enchantments = [{ id: "power", level: 1 }];
                        if (this.id === "bow_power_punch") enchantments = [{ id: "power", level: 1 }, { id: "punch", level: 1 }];
                        giveItem(player, this.itemId, { enchantments });
                    });
                    break;
                    
                case "potion":
                    purchaseTest(() => {
                        switch (this.id) {
                            case "potion_jump_boost": 
                                giveItem(player, this.itemId, { lore: ["", "§r§9跳跃提升 V (0:45)"] }); 
                                break;
                            case "potion_speed": 
                                giveItem(player, this.itemId, { lore: ["", "§r§9迅捷 II (0:45)"] }); 
                                break;
                            case "potion_invisibility": 
                                giveItem(player, this.itemId, { lore: ["", "§r§9隐身 (0:30)"] }); 
                                break;
                        }
                    });
                    break;
                    
                case "other":
                    purchaseTest(() => {
                        giveItem(player, this.itemId, { amount: this.itemAmount, itemLock: "inventory" });
                    });
                    break;
                    
                case "teamUpgrade":
                    if (!playerTeamUpgrade) return;
                    
                    switch (this.id) {
                        case "sharpened_swords_tier_1":
                        case "sharpened_swords_tier_2":
                            purchaseTest(() => {
                                // 直接设置购买的等级
                                playerTeamUpgrade.sharpenedSwords = this.tier;
                                
                                // 更新所有玩家的装备
                                eachValidPlayer(teamPlayer => {
                                    if (teamPlayer.bedwarsInfo?.team === player.bedwarsInfo?.team) {
                                        teamPlayer.bedwarsInfo.equipment.axe = 0;
                                        teamPlayer.bedwarsInfo.equipment.pickaxe = 0;
                                    }
                                });
                            }, { 
                                // 检查是否已经拥有相同或更高等级
                                itemGot: playerTeamUpgrade.sharpenedSwords >= this.tier,
                                isTeamUpgrade: true,
                                currentLevel: playerTeamUpgrade.sharpenedSwords || 0,
                                name: "sharpened_sword"
                            });
                            break;
                            
                        case "reinforced_armor_tier_1":
                        case "reinforced_armor_tier_2":
                        case "reinforced_armor_tier_3":
                        case "reinforced_armor_tier_4":
                            purchaseTest(() => {
                                playerTeamUpgrade.reinforcedArmor = (playerTeamUpgrade.reinforcedArmor || 0) + 1;
                            }, { 
                                currentLevel: playerTeamUpgrade.reinforcedArmor || 0, 
                                isTeamUpgrade: true, 
                                name: "reinforced_armor" 
                            });
                            break;
                            
                        case "maniac_miner_tier_1":
                        case "maniac_miner_tier_2":
                            purchaseTest(() => {
                                playerTeamUpgrade.maniacMiner = (playerTeamUpgrade.maniacMiner || 0) + 1;
                            }, { 
                                currentLevel: playerTeamUpgrade.maniacMiner || 0, 
                                isTeamUpgrade: true, 
                                name: "maniac_miner" 
                            });
                            break;
                            
                        case "forge_tier_1":
                        case "forge_tier_2":
                        case "forge_tier_3":
                        case "forge_tier_4":
                            purchaseTest(() => {
                                playerTeamUpgrade.forge = (playerTeamUpgrade.forge || 0) + 1;
                            }, { 
                                currentLevel: playerTeamUpgrade.forge || 0, 
                                isTeamUpgrade: true, 
                                name: "forge" 
                            });
                            break;
                            
                        case "heal_pool":
                            purchaseTest(() => {
                                playerTeamUpgrade.healPool = true;
                            }, { itemGot: playerTeamUpgrade.healPool, isTeamUpgrade: true });
                            break;
                            
                        case "dragon_buff":
                            purchaseTest(() => {
                                playerTeamUpgrade.dragonBuff = true;
                            }, { itemGot: playerTeamUpgrade.dragonBuff, isTeamUpgrade: true });
                            break;
                    }
                    break;
                    
                case "trap":
                    if (!playerTeamUpgrade) return;
                    
                    purchaseTest(() => {
                        if (!playerTeamUpgrade.trap1Type) {
                            playerTeamUpgrade.trap1Type = this.id;
                        } else if (!playerTeamUpgrade.trap2Type) {
                            playerTeamUpgrade.trap2Type = this.id;
                        } else if (!playerTeamUpgrade.trap3Type) {
                            playerTeamUpgrade.trap3Type = this.id;
                        }
                    }, { 
                        isTeamUpgrade: true, 
                        costAdder: playerTeamUpgrade.trap1Type ? 
                                 (playerTeamUpgrade.trap2Type ? 
                                  (playerTeamUpgrade.trap3Type ? 7 : 3) : 1) : 0,
                        trapQueueFull: !!playerTeamUpgrade.trap3Type 
                    });
                    break;
            }
        }
    }


class CategoryTag {
    constructor(name) {
        this.name = name;
        this.id = `bedwars:category_${categoryIds[name]}`;
        this.items = categoryItems[name] || [];
    }

    setCategoryItems(player, page = 0) {
        const startIndex = page * 18;
        const itemsToShow = this.items.slice(startIndex, startIndex + 18);
        
        overworld.getEntities({ type: "bedwars:trader" })
            .filter(trader => trader.nameTag === "§a物品商店")
            .forEach(trader => {
                const inventory = trader.getComponent("minecraft:inventory").container;
                
                // 清空商品槽位 (9-26)
                for (let i = 9; i < 27; i++) {
                    inventory.setItem(i, undefined);
                }
                
                // 填充当前页商品
                itemsToShow.forEach((item, index) => {
                    if (item instanceof Shopitem) {
                        item.setTraderItem(9 + index);
                    }
                });
                
                // 更新页码显示
                this.updatePageDisplay(player, page);
            });
    }
    
    updatePageDisplay(player, page) {
        const maxPage = Math.max(0, Math.floor((this.items.length - 1) / 18));
        const slotIndex = categoryNames.indexOf(this.name);
        
        overworld.getEntities({ type: "bedwars:trader" })
            .filter(trader => trader.nameTag === "§a物品商店")
            .forEach(trader => {
                const inventory = trader.getComponent("minecraft:inventory").container;
                const currentItem = inventory.getItem(slotIndex);
                
                if (currentItem) {
                    const newItem = currentItem.clone();
                    newItem.setLore([`§r§e页码: §a${page + 1}/${maxPage + 1}`]);
                    inventory.setItem(slotIndex, newItem);
                }
            });
    }


        clearTraderSlot(slot) {
            overworld.getEntities({ type: "bedwars:trader" })
                .filter(trader => {
                    const typeFamily = trader.getComponent("minecraft:type_family");
                    return typeFamily && typeFamily.hasTypeFamily("combined_trader");
                })
                .forEach(trader => {
                    const inventory = trader.getComponent("minecraft:inventory")?.container;
                    if (inventory && inventory.getItem(slot)) {
                        inventory.setItem(slot, undefined);
                    }
                });
        }
    }

    // === 常量定义 ===
const shopitemType = ["sword", "armor", "axe", "pickaxe", "teamUpgrade", "coloredBlock", "knockbackStick", "shears", "bow", "potion", "trap", "other"];
const traderType = ["combined", "team_upgrade"];

/** 分类名称列表 */
const categoryNames = [
    "方块", "武器", "护甲","工具", "弓箭", "药水", "道具", "资源", "轮换物品"
];

/** 分类ID映射 */
const categoryIds = {
    "方块": "blocks",
    "武器": "weapons",
    "护甲": "armor",
    "工具": "tools",
    "弓箭": "bows",
    "药水": "potions",
    "道具": "items",
    "资源": "resources",
    "轮换物品": "rotating"
};

/** 方块与物品商品列表 */
export const blocksAndItemsShopitems = [
    new Shopitem( "wool", "combined_trader", 4, 16, { itemType: "coloredBlock", description: "经济实惠的搭路方块." } ),
    new Shopitem( "stained_hardened_clay", "combined_trader", 24, 12, { itemType: "coloredBlock", description: "用于保卫床的基础方块." } ),
    new Shopitem( "blast_proof_glass", "combined_trader", 16, 4, { itemType: "coloredBlock", description: "怎么炸?" } ),
    new Shopitem( "end_stone", "combined_trader", 32, 8, { description: "较为坚固的方块!" } ),
    new Shopitem( "planks", "combined_trader", 24, 12, { description: "为床提供保护的不错块选.\n 只带了镐子的话就难受了.", itemId: "bedwars:oak_planks" } ),
    new Shopitem( "ladder", "combined_trader", 12, 8, { description: "可用于救助困在树上的猫猫.", itemId: "minecraft:ladder" } ),
    new Shopitem( "obsidian", "combined_trader", 400, 4, { description: "坚不可摧!" } ),

    new Shopitem( "potion_speed", "combined_trader", 150, 1, { description: "§9速度 II (0:30)", itemType: "potion" } ),
    new Shopitem( "potion_jump_boost", "combined_trader", 150, 1, { description: "§9跳跃提升 V (0:45)", itemType: "potion" } ),
    new Shopitem( "potion_invisibility", "combined_trader", 300, 1, { description: "§9完全隐身 (0:30)", itemType: "potion" } ),
    new Shopitem( "potion_strength_1", "combined_trader", 200, 1, {itemType: "potion"}),
    new Shopitem( "potion_instant_health_I", "combined_trader", 75, 1 ,{itemType: "potion"}),
    new Shopitem( "potion_instant_health_II", "combined_trader", 150, 1 ,{itemType: "potion"}),

    new Shopitem( "golden_apple", "combined_trader", 30, 1, { description: "疗伤好物。", itemId: "minecraft:golden_apple" } ),
    new Shopitem( "bed_bug", "combined_trader", 40, 1, { description: "在雪球砸中的地方产生一只持续\n 15 秒的蠹虫，为你吸引火力。" } ),
    new Shopitem( "dream_defender", "combined_trader", 100, 1, { description: "让铁傀儡成为你的守家好帮手。\n 持续 4 分钟。" } ),
    new Shopitem( "fireball", "combined_trader", 50 , 1, { description: "右键发射！击飞在桥上行走的敌人！" } ),
    new Shopitem( "tnt", "combined_trader", 50, 1, { description: "放下后即点燃。要炸毁什么\n 东西，它很在行！" } ),
    new Shopitem( "ender_pearl", "combined_trader", 400, 1, { description: "快速打入敌人内部。", itemId: "minecraft:ender_pearl" } ),
    new Shopitem( "water_bucket", "combined_trader", 30, 1, { description: "使来犯敌人减速的良好选择。\n 也能应对 TNT 的威胁。", itemId: "minecraft:water_bucket" } ),
    new Shopitem( "bridge_egg", "combined_trader", 100, 1, { description: "能够沿着其扔出的轨迹\n 创造一座桥梁。" } ),
    new Shopitem( "magic_milk", "combined_trader", 150, 1, { description: "饮用后能够在 30 秒内\n 防止触发敌人的陷阱。" } ),
    new Shopitem( "sponge", "combined_trader", 100, 4, { description: "吸水好手。", itemId: "minecraft:sponge" } ),
    new Shopitem( "rescue_platform", "combined_trader", 150, 1, { description: "经常被虚空刷人头?别担心! \n 在你脚下生成一个平台。\n 仅1绿宝石!" }),
    new Shopitem( "totem_of_undying", "combined_trader", 1024, 1, { description: "达成成就 §e超越生死!\n 拿在手上生效.\n 每局限购一次!",itemId:"minecraft:totem_of_undying",buyCount:1 }),
    new Shopitem("wind_charge","combined_trader", 160, 1, {description:"核动力推动\n§e更快!",itemId:"minecraft:wind_charge"})
]
    
/** 武器与盔甲商品列表 */
export const weaponAndArmorShopitems = [ 
    new Shopitem( "stone_sword", "combined_trader", 10, 1, { description:"基础的武器.", itemType: "sword" } ),
    new Shopitem( "iron_sword", "combined_trader", 70, 1, { description:"前期必备!", itemType: "sword" } ),
    new Shopitem( "diamond_sword", "combined_trader", 300, 1, { description:"只是过渡而已.", itemType: "sword" } ),
    new Shopitem( "netherite_sword", "combined_trader", 500, 1, { description:"斩碎万物!", itemType: "sword"}),
    new Shopitem( "seven_deadly_sins", "combined_trader", 700, 1, { description:"这力量只属于你!", itemType:"sword"}),
    new Shopitem( "knockback_stick", "combined_trader", 50, 1, { description:"把敌人击飞吧!", itemType: "knockbackStick" } ),
    //new Shopitem( "fishing_rod")
    
    new Shopitem( "chain_armor", "combined_trader", 50, 1, { description: "起码比没有好.", itemType: "armor" } ),
    new Shopitem( "iron_armor", "combined_trader", 120, 1, { description: "坚固的铁才能保护脆弱的心.", itemType: "armor" } ),
    new Shopitem( "diamond_armor", "combined_trader", 600, 1, { description: "闪耀光芒!", itemType: "armor" } ),
    new Shopitem( "netherite_armor", "combined_trader", 800, 1, {description: "无懈可击!", itemType: "armor"}),
    new Shopitem( "shears", "combined_trader", 20, 1, { description: "破坏羊毛的得力工具。\n 该物品是永久的。", itemType: "shears" } ),
    new Shopitem( "wooden_axe", "combined_trader", 15, 1, { tier: 1, isHighestTier: false, loseTierUponDeath: true, itemType: "axe" } ),
    new Shopitem( "stone_axe", "combined_trader", 30, 1, { tier: 2, isHighestTier: false, loseTierUponDeath: true, itemType: "axe" } ),
    new Shopitem( "iron_axe", "combined_trader", 60, 1, { tier: 3, isHighestTier: false, loseTierUponDeath: true, itemType: "axe" } ),
    new Shopitem( "diamond_axe", "combined_trader", 100, 1, { tier: 4, isHighestTier: true, loseTierUponDeath: true, itemType: "axe" } ),
    new Shopitem( "wooden_pickaxe", "combined_trader", 15, 1, { tier: 1, isHighestTier: false, loseTierUponDeath: true, itemType: "pickaxe" } ),
    new Shopitem( "iron_pickaxe", "combined_trader", 30, 1, { tier: 2, isHighestTier: false, loseTierUponDeath: true, itemType: "pickaxe" } ),
    new Shopitem( "golden_pickaxe", "combined_trader", 60, 1, { tier: 3, isHighestTier: false, loseTierUponDeath: true, itemType: "pickaxe" } ),
    new Shopitem( "diamond_pickaxe", "combined_trader", 100, 1, { tier: 4, isHighestTier: true, loseTierUponDeath: true, itemType: "pickaxe" } ),
    new Shopitem( "bow", "combined_trader", 100, 1, { itemId: "minecraft:bow", itemType: "bow" } ),
    new Shopitem( "bow_power", "combined_trader", 200, 1, { itemId: "minecraft:bow", itemType: "bow" } ),
    new Shopitem( "bow_power_punch", "combined_trader", 300, 1, { itemId: "minecraft:bow", itemType: "bow" } ),
    new Shopitem( "arrow", "combined_trader", 64, 16, { itemId: "minecraft:arrow" } )
]
    
/** 团队升级商品列表 */
export const teamUpgradeShopitems = [ 
    new Shopitem( "sharpened_swords_tier_1", "team_upgrade", 0, 1, { 
        description: "己方所有成员的剑和斧\n 将永久获得锋利 I 的效果！", 
        itemType: "teamUpgrade", 
        costResourceType: "diamond", 
        costResourceAmount: 16,
        costResourceAmountInSolo: 8 
    } ),
    new Shopitem( "sharpened_swords_tier_2", "team_upgrade", 0, 2, { 
        description: "己方所有成员的剑和斧\n 将永久获得锋利 II 的效果！", 
        itemType: "teamUpgrade", 
        costResourceType: "diamond", 
        costResourceAmount: 32,
        costResourceAmountInSolo: 20
    } ),
    new Shopitem( "reinforced_armor_tier_1", "team_upgrade", 0, 1, { 
        description: "己方所有成员的盔甲将获得永久保护附魔！\n 效果： 保护 I", 
        itemType: "teamUpgrade", 
        tier: 1, 
        isHighestTier: false, 
        costResourceType: "diamond", 
        costResourceAmount: 8,
        costResourceAmountInSolo: 5 
    } ),
    new Shopitem( "reinforced_armor_tier_2", "team_upgrade", 0, 2, { 
        description: "己方所有成员的盔甲将获得永久保护附魔！\n 效果： 保护 II", 
        itemType: "teamUpgrade", 
        tier: 2, 
        isHighestTier: false, 
        costResourceType: "diamond", 
        costResourceAmount: 16,
        costResourceAmountInSolo: 10
    } ),
    new Shopitem( "reinforced_armor_tier_3", "team_upgrade", 0, 3, { 
        description: "己方所有成员的盔甲将获得永久保护附魔！\n 效果： 保护 III", 
        itemType: "teamUpgrade", 
        tier: 3, 
        isHighestTier: false, 
        costResourceType: "diamond", 
        costResourceAmount: 32,
        costResourceAmountInSolo: 20
    } ),
    new Shopitem( "maniac_miner_tier_1", "team_upgrade", 0, 1, { 
        description: "己方所有成员获得永久急迫效果。\n 效果： 急迫 I", 
        itemType: "teamUpgrade", 
        tier: 1, 
        isHighestTier: false, 
        costResourceType: "diamond", 
        costResourceAmount: 4,
        costResourceAmountInSolo: 2 
    } ),
    new Shopitem( "maniac_miner_tier_2", "team_upgrade", 0, 2, { 
        description: "己方所有成员获得永久急迫效果。\n 效果： 急迫 II", 
        itemType: "teamUpgrade", 
        tier: 2, 
        isHighestTier: true, 
        costResourceType: "diamond", 
        costResourceAmount: 6,
        costResourceAmountInSolo: 4 
    } ),
    new Shopitem( "forge_tier_1", "team_upgrade", 0, 1, { 
        description: "升级你岛屿资源池的生成速度和最大容量。\n 效果： +50% 资源", 
        itemType: "teamUpgrade", 
        tier: 1, 
        isHighestTier: false, 
        costResourceType: "diamond", 
        costResourceAmount: 4,
        costResourceAmountInSolo: 2 
    } ),
    new Shopitem( "forge_tier_2", "team_upgrade", 0, 2, { 
        description: "升级你岛屿资源池的生成速度和最大容量。\n 效果： +100% 资源", 
        itemType: "teamUpgrade", 
        tier: 2, 
        isHighestTier: false, 
        costResourceType: "diamond", 
        costResourceAmount: 8,
        costResourceAmountInSolo: 4 
    } ),
    new Shopitem( "forge_tier_3", "team_upgrade", 0, 3, { 
        description: "升级你岛屿资源池的生成速度和最大容量。\n 效果： 生成绿宝石", 
        itemType: "teamUpgrade", 
        tier: 3, 
        isHighestTier: false, 
        costResourceType: "diamond", 
        costResourceAmount: 12,
        costResourceAmountInSolo: 6 
    } ),
    new Shopitem( "forge_tier_4", "team_upgrade", 0, 4, { 
        description: "升级你岛屿资源池的生成速度和最大容量。\n 效果： +200% 资源", 
        itemType: "teamUpgrade", 
        tier: 4, 
        isHighestTier: true, 
        costResourceType: "diamond", 
        costResourceAmount: 16,
        costResourceAmountInSolo: 8 
    } ),
    new Shopitem( "heal_pool", "team_upgrade", 0, 1, { 
        description: "基地附近的队伍成员将拥有生命恢复效果！", 
        itemType: "teamUpgrade", 
        costResourceType: "diamond", 
        costResourceAmount: 3,
        costResourceAmountInSolo: 1 
    } ),
    new Shopitem( "dragon_buff", "team_upgrade", 0, 1, { 
        description: "你的队伍在绝杀模式中将会有两条末影龙而不是一条！", 
        itemType: "teamUpgrade", 
        costResourceType: "diamond", 
        costResourceAmount: 5 
    } ),
    new Shopitem( "its_a_trap", "team_upgrade", 0, 1, { 
        description: "造成失明和缓慢效果，持续 8 秒。", 
        itemType: "trap", 
        costResourceType: "diamond", 
        costResourceAmount: 1 
    } ),
    new Shopitem( "counter_offensive_trap", "team_upgrade", 0, 1, { 
        description: "赋予基地附近的队友速度 II 与跳跃提升 II\n 效果，持续 15 秒。", 
        itemType: "trap", 
        costResourceType: "diamond", 
        costResourceAmount: 1 
    } ),
    new Shopitem( "alarm_trap", "team_upgrade", 0, 1, { 
        description: "让隐身的敌人立刻显形，并警报入侵者的名字和队伍。", 
        itemType: "trap", 
        costResourceType: "diamond", 
        costResourceAmount: 1 
    } ),
    new Shopitem( "miner_fatigue_trap", "team_upgrade", 0, 1, { 
        description: "造成挖掘疲劳效果，持续 10 秒。", 
        itemType: "trap", 
        costResourceType: "diamond", 
        costResourceAmount: 1 
    } )
]

/** 分类物品映射 */
export const categoryItems = {
    "方块": [
        blocksAndItemsShopitems[0],
        blocksAndItemsShopitems[1],
        blocksAndItemsShopitems[2], 
        blocksAndItemsShopitems[3], 
        blocksAndItemsShopitems[4],
        blocksAndItemsShopitems[5],
        blocksAndItemsShopitems[6]
    ],
    "武器": [
        weaponAndArmorShopitems[0],
        weaponAndArmorShopitems[1],
        weaponAndArmorShopitems[2],
        weaponAndArmorShopitems[3],
        weaponAndArmorShopitems[4],
        weaponAndArmorShopitems[5]
    ],
    "护甲": [
        weaponAndArmorShopitems[6],
        weaponAndArmorShopitems[7],
        weaponAndArmorShopitems[8], 
        weaponAndArmorShopitems[9]
    ],
    "工具": [
        weaponAndArmorShopitems[10],
        weaponAndArmorShopitems[11],
        weaponAndArmorShopitems[12],
        weaponAndArmorShopitems[13],
        weaponAndArmorShopitems[14],
        weaponAndArmorShopitems[15],
        weaponAndArmorShopitems[16],
        weaponAndArmorShopitems[17],
        weaponAndArmorShopitems[18]
    ],
    "弓箭": [
        weaponAndArmorShopitems[19],
        weaponAndArmorShopitems[20],
        weaponAndArmorShopitems[21],
        weaponAndArmorShopitems[22]
    ],
    "药水": [
        blocksAndItemsShopitems[7],
        blocksAndItemsShopitems[8],
        blocksAndItemsShopitems[9],
        blocksAndItemsShopitems[10],
        blocksAndItemsShopitems[11],
        blocksAndItemsShopitems[12]
    ],
    "道具": [
        blocksAndItemsShopitems[13],
        blocksAndItemsShopitems[14],
        blocksAndItemsShopitems[15],
        blocksAndItemsShopitems[16],
        blocksAndItemsShopitems[17],
        blocksAndItemsShopitems[18],
        blocksAndItemsShopitems[19],
        blocksAndItemsShopitems[20],
        blocksAndItemsShopitems[21],
        blocksAndItemsShopitems[22],
        blocksAndItemsShopitems[23],
        blocksAndItemsShopitems[24],
        blocksAndItemsShopitems[25]
    ],
    "资源": [], // 示例留空
    "轮换物品": [] // 示例留空
};

    // === 创建分类标签 ===
export const categoryTags = categoryNames.map(name => new CategoryTag(name));

// 商店系统实现
export const shopSystem = (function() {

const shopStates = new Map();

function getShopState(player) {
    if (!shopStates.has(player.id)) {
        shopStates.set(player.id, {
            currentCategory: null,
            currentPage: 0
        });
    }
    return shopStates.get(player.id);
}

function resetShopState(player) {
    shopStates.delete(player.id);
}

    // === 商人初始化 ===
    let initialized = false;
    function initCombinedTrader() {
        // 放置分类标签
        categoryTags.forEach((tag, index) => {
            const item = itemInfo(tag.id, { 
                nameTag: `§b${tag.name}`,
                lore: ["§e页码: §a1/1"],
                amount: 1
            });
            
            overworld.getEntities({ type: "bedwars:trader" })
                .filter(trader => {
                    const typeFamily = trader.getComponent("minecraft:type_family");
                    return typeFamily && typeFamily.hasTypeFamily("combined_trader");
                })
                .forEach(trader => {
                    const inventory = trader.getComponent("minecraft:inventory")?.container;
                    if (inventory) {
                        inventory.setItem(index, item);
                    }
                });
        });
        
        // 设置第一个分类的初始物品
        if (categoryTags[0]) {
            categoryTags[0].setCategoryItems(null, 0);
        }
    }

    // === 分类点击处理 ===
function handleCategoryClick(player, categoryId) {
    const state = getShopState(player);
    const tag = categoryTags.find(t => t.id === categoryId);
    if (!tag) return;
    
    // 如果是新分类，重置页码
    if (state.currentCategory !== categoryId) {
        state.currentCategory = categoryId;
        state.currentPage = 0;
    } 
    // 如果是同一分类，翻页
    else {
        const maxPage = Math.floor((tag.items.length - 1) / 18);
        state.currentPage = (state.currentPage + 1) % (maxPage + 1);
    }
    
    // 更新商店显示
    tag.setCategoryItems(player, state.currentPage);
}

    // === 交易函数 ===
return function tradeFunction() {
    if (!initialized) {
        initCombinedTrader();
        initialized = true;
    }

    // 物品栏锁定逻辑（只在商人附近生效）
    eachPlayer(player => {
        const hasTraderNearby = player.runCommand("execute if entity @e[r=3.5,type=bedwars:trader]")?.successCount === 1;
        const inventory = player.getComponent("minecraft:inventory")?.container;
        
        if (inventory) {
            for (let i = 0; i < inventory.size; i++) {
                const item = inventory.getItem(i);
                if (!item) continue;
                
                // 当玩家在商人附近时，锁定分类标签和商店物品
                if (hasTraderNearby && 
                    (item.typeId.includes("bedwars:category_") || 
                     item.typeId.includes("bedwars:shopitem_") ||
                     item.typeId.includes("bedwars:upgrade_"))) {
                    item.lockMode = "slot";
                    inventory.setItem(i, item);
                } else {
                    item.lockMode = "none";
                    inventory.setItem(i, item);
                }
            }
        }
    });
    
    // 填充团队升级商人
    const teamUpgradeTraders = overworld.getEntities({ 
        type: "bedwars:trader",
        name: "§b团队升级"
    });
    
    teamUpgradeTraders.forEach(trader => {
        const inventory = trader.getComponent("minecraft:inventory")?.container;
        if (!inventory) return;
        
        // 填充团队升级物品
        teamUpgradeShopitems.forEach((item, index) => {
            item.setTraderItem(index);
        });
    });
    
    // 处理玩家交互
    eachPlayer(player => {
        // 分类点击
categoryTags.forEach(tag => {
    if (player.runCommand(`execute if entity @s[hasitem={item=${tag.id}}]`).successCount === 1) {
        player.runCommand(`clear @s ${tag.id}`);
        
        // 获取或初始化玩家商店状态
        const state = getShopState(player);
        
        // 如果是新分类，重置页码
        if (state.currentCategory !== tag.id) {
            state.currentCategory = tag.id;
            state.currentPage = 0;
        } 
        // 同一分类则翻页
        else {
            const maxPage = Math.floor((tag.items.length - 1) / 18);
            state.currentPage = (state.currentPage + 1) % (maxPage + 1);
        }
        
        // 更新商店显示
        tag.setCategoryItems(player, state.currentPage);
    }
});
        
        // 物品购买
        blocksAndItemsShopitems.forEach(item => item.playerPurchaseItems(player));
        weaponAndArmorShopitems.forEach(item => item.playerPurchaseItems(player));
        teamUpgradeShopitems.forEach(item => item.playerPurchaseItems(player));
        
        // 更新当前分类显示
        const state = getShopState(player);
        if (state.currentCategory) {
            const tag = categoryTags.find(t => t.id === state.currentCategory);
            if (tag) {
                tag.setCategoryItems(player, state.currentPage);
            }
        }
    });
    
    // 清理掉落物
    overworld.getEntities({ type: "minecraft:item" }).forEach(item => {
        const itemStack = item.getComponent("minecraft:item")?.itemStack;
        if (itemStack && (itemStack.typeId.includes("bedwars:shopitem_") || 
                          itemStack.typeId.includes("bedwars:upgrade_") || 
                          itemStack.typeId.includes("bedwars:category_"))) {
            item.remove();
        }
    });
    
    // 区域限制
    if (map() && !map().playerCouldIntoShop) {
        eachPlayer(player => {
            if (playerIsAlive(player)) {
                player.runCommand(`function maps/${map().id}/player_into_shop`);
            }
        });
    }
};
})();

// === 导出交易函数 ===
export const tradeFunction = shopSystem;
