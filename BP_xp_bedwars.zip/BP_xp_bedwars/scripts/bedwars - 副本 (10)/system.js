import { system,world } from "@minecraft/server"

export class GameSystem {
    /** 性能循环,在不必要时回调函数清除循环 */
    static Interval( callback, delay ){
        const handle = system.runInterval( ()=> {
            let cancel = callback()
            cancel === true ? system.clearRun(handle) : null
            //world.sendMessage(`${handle},${cancel}`)
        }, delay)
        return handle;
    }
}