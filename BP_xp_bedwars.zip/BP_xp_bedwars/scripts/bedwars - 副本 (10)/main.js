import { system, world } from "@minecraft/server";
import { regenerateMap, map } from "./maps.js";
import * as bedwarsEvents from "./events.js";
import * as bot from "./bot.js"
import { xp } from "./xp.js"
import {newCommand} from "./command.js"
import { overworld } from "./constants.js";
import { eachPlayer } from "./methods.js";

    //system.beforeEvents.startup.subscribe((init)=>{newCommand(init)})

    /** 地图创建 */
    regenerateMap();

    /** 起床战争功能 */

    if ( map() !== undefined ) {
        world.beforeEvents.playerBreakBlock.subscribe( event => { bedwarsEvents.playerBreakBlockEvent( event ); } )
        world.afterEvents.itemCompleteUse.subscribe( event => { bedwarsEvents.playerUsePotionAndMagicMilkEvent( event );} )
        world.afterEvents.projectileHitEntity.subscribe( event => { bedwarsEvents.bedBugEvent( event ); bedwarsEvents.hurtByFireballsEvent( event ); bedwarsEvents.enderPearlEvent( event); bedwarsEvents.arrowHit(event) } )
        world.afterEvents.projectileHitBlock.subscribe( event => { bedwarsEvents.bedBugEvent( event ); bedwarsEvents.hurtByFireballsEvent( event ); bedwarsEvents.enderPearlEvent( event ) } )
        world.beforeEvents.itemUse.subscribe( event => { bedwarsEvents.dreamDefenderEvent( event ); } )
        world.afterEvents.itemUse.subscribe( event => { bedwarsEvents.playerUseWaterBucketEvent( event ); bedwarsEvents.playerUseBridgeEggEvent( event ); bedwarsEvents.playerUseFireballEvent( event )} )
        world.afterEvents.playerPlaceBlock.subscribe( event => { bedwarsEvents.playerUseTNTEvent( event ); bedwarsEvents.towerAndWall( event );bedwarsEvents.playerUseItemOnHeightLimitEvent( event ); } )
        world.beforeEvents.explosion.subscribe( event => { bedwarsEvents.explosionEvents( event ); } )
        world.afterEvents.explosion.subscribe( event => { bedwarsEvents.explosionKB( event )})
        world.afterEvents.entityHurt.subscribe( event => { bedwarsEvents.hurtByPlayerEvent( event );} )
        world.afterEvents.entityDie.subscribe( event => { bedwarsEvents.playerDieEvent( event ); } )
        world.afterEvents.playerSpawn.subscribe( event => { bedwarsEvents.playerRejoinEvent( event ); } )
        world.beforeEvents.playerLeave.subscribe( event => { bedwarsEvents.playerLeaveEvent( event ); } )
        world.beforeEvents.chatSend.subscribe( event => {bot.makeBot( event )})
        world.afterEvents.playerInteractWithEntity.subscribe( event => { bedwarsEvents.afterInteractWithTraderEvent( event ); } )
        world.beforeEvents.playerInteractWithEntity.subscribe( event => { bedwarsEvents.beforeInteractWithTraderEvent( event ); } )
        world.afterEvents.playerInventoryItemChange.subscribe( event => { bedwarsEvents.fastShopFunction( event );})
        system.afterEvents.scriptEventReceive.subscribe( event => { bedwarsEvents.settingsEvent( event ) } )
    }

    system.runInterval( () => {
        if ( map !== undefined ) {
            xp()
            if ( map().gameStage === 0 ) {
                bedwarsEvents.waitingFunction();
            }
            else if ( map().gameStage === 1 ) {
                bedwarsEvents.EPsimple();
                bedwarsEvents.ETsimple();
                bedwarsEvents.EVPsimple();
                //bedwarsEvents.bridgeEggFunction();
                //bedwarsEvents.explosionFunction();
            }
            else {
                bedwarsEvents.gameOverEvent();
            }
        }
    } )

    system.runInterval( ()=> {
        if(map().gameStage === 1){
            bedwarsEvents.spawnResourceFunction();
        }
    },5)

    system.runInterval( () => {
        if(map() !== undefined){
            bedwarsEvents.effectFunction();
            if(map().gameStage === 1){
                bedwarsEvents.scoreboardFunction();
                bedwarsEvents.gameEventFunction();
                bedwarsEvents.teamFunction();
            }
            else if(map().gameStage === 2){
                bedwarsEvents.scoreboardFunction()
            }
        }
    },20)