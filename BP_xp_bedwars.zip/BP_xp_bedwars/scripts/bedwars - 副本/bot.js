import { GameMode, ItemStack, system, world } from "@minecraft/server";
import { SimulatedPlayer, register } from "@minecraft/server-gametest";
import { randomInt } from "./methods"

var mtest; /**Test 存储 */

function getTest(test) {
    mtest = test;
    // test.spawnSimulatedPlayer({x:0,y:0,z:0},"清风",GameMode.survival);
}
register("newTest", "test", getTest).maxTicks(1728000).structureName("test:aaa");
// gametest run startertests:simplemobtest
//StarterTests:simpleMobTest

export function makeBot(event){
    let player = event.sender;
    let mesg = event.message;
    if(player.name!=="CutePandaBL") return;
    if (mesg == "#makebot") {
        system.run(() => {
            newBot(player.location, 1);
        });
        event.cancel = true;
    }
}

const nameArray = ["张哥之雅思八分","妖猫之圈钱梦想","BMW创亖你"]

function newBot(location, num = 3) {
    const nameArray_copy = []
    for(let index = 0; index<nameArray.length; index++){
        nameArray_copy.push(nameArray[index])
    }
    if (!mtest) {
        world.sendMessage(`未找到Test对象!`)
        return;
    }
    for (let index = 1; index <= num; index++) {
        let random = randomInt(0,nameArray_copy.length)
        let spawn_location = mtest.relativeLocation(location);
        spawn_location.x += index;
        let sm_player = mtest.spawnSimulatedPlayer(spawn_location, `${nameArray_copy[random]}`, GameMode.survival);
        nameArray_copy.splice(random,1)
        sm_player.setSpawnPoint({ dimension: sm_player.dimension, x: sm_player.location.x, y: sm_player.location.y, z: sm_player.location.z });
        sm_player.nametag = `[bot]${sm_player.nametag}`
        sm_players.push(sm_player);
    }
}
let sm_players = [];

world.afterEvents.entityDie.subscribe((e) => {
    let sm_player = e.deadEntity instanceof SimulatedPlayer ? e.deadEntity : undefined;
    if (sm_player) {
        sm_player.respawn();
    }
});