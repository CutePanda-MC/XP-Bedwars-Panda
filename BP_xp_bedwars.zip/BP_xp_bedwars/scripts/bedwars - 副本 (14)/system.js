import { system } from "@minecraft/server"

export class GameEvent{

    //运行池，处理订阅函数
    /**@type {Function[]}*/runPool = []

    //事件id，用于标注
    /**@type {String} */id = "";

    //事件对象传入，由trigger()传入，给予runPool
    /**@type {Object} */event = {}

    //构建器
    constructor(id){
        this.id = id;
    }

    /**
     * @param {Function} callback  
     * 订阅事件 
     */
    subscribe(callback){
        return this.runPool.push(callback);
    }

    /**
     * @param {Number} functionId 
     * 对事件取消订阅
     */
    unsubscribe(functionId){
        this.runPool.splice(functionId,1);
    }

    trigger(event){
        this.event = event;
        this.runPool.forEach( (fun) => {
            fun(this.event)
        })
    }
}

export class GameSystem {

    //游戏after事件集
    /** @type {{afterMapCreate: GameEvent, afterGameStart: GameEvent, afterGameEnd: GameEvent, afterGameInit: GameEvent}} */ 
    static afterGameEvents = {
        afterMapCreate: new GameEvent("afterMapCreate"),
        afterGameStart: new GameEvent("afterGameStart"),
        afterGameEnd: new GameEvent("afterGameEnd"),
        afterGameInit: new GameEvent("afterGameInit")
    }

    /** 性能循环,在不必要时回调函数清除循环 */
    static Interval( callback, delay = 1 ){
        // 给 delay 一个默认值，避免调用方忘记传参导致 runInterval 抛错
        const handle = system.runInterval( ()=> {
            try{
                let cancel = callback()
                if ( cancel === true ) {
                    // 部分运行时可能使用不同的清除接口，优先调用 clearRun
                    try{ system.clearRun(handle) }catch(e){ /* ignore */ }
                }
            }catch(e){
                // 捕获回调内异常以避免整个系统崩溃
                // world.sendMessage && world.sendMessage(`GameSystem.Interval callback error: ${e}`)
            }
        }, delay)
        return handle;
    }
}